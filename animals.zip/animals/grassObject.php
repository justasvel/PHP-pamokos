<?php
if (isset($_POST['submit'])) {

    require_once 'animals.php';

    $grass = new Grass($_POST['weight'], $_POST['region']);
    $postin = get_class($grass);

    ob_start();

    include __DIR__ . '/templates/createdAnimal.html.php';

    $output = ob_get_clean();

} else {
    ob_start();

    include __DIR__ . '/templates/createGrass.html.php';

    $output = ob_get_clean();
}


include __DIR__ . '/templates/layout.html.php';