<h1>Which animal would you like to create?</h1>
<form action="grass.php" method="post">
    <input type="radio" id="grass" name="animal" value="Grass">Grass<br>
    <input type="radio" id="swimming" name="animal" value="Swimming Animal">Swimming Animal<br>
    <input type="radio" id="land" name="animal" value="Land Animal">Land Animal<br>
    <input type="submit" name="button" value="Submit"/>
</form>