<form action="grassObject.php" method="POST">
  <label for="grass">Enter grass weight:</label><br>
  <input type="number" step="0.1" id="weight" name="weight" placeholder="Weight in kilos..."><br>
  <label for="lname">Enter grass region:</label><br>
  <input type="text" id="region" name="region" placeholder="Region name..."><br><br>
  <input type="submit" value="submit" name="submit">
</form> 