<!doctype html>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Animals</title>
        <meta name="description">
        <meta name="author">
    </head>

    <body>
        <div>
            <?=$output?>
        </div>
    </body>
</html>